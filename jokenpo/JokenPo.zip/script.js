// 1 - pedra
// 2 - papel
// 3 - tesoura


let pedra = function(){
    let machine = Math.round(Math.random() * (3 - 1) + 1)
    if(machine == 1){
        document.getElementById('result').innerHTML = "Pedra X Pedra = Empate"
    }
    else if(machine == 2){
        document.getElementById('result').innerHTML = "Pedra X Papel = Derrota"
    }
    else{
        document.getElementById('result').innerHTML = "Pedra X Tesoura = Vitória"
    }
}

let papel = function(){
    let machine = Math.round(Math.random() * (3 - 1) + 1)
    if(machine == 1){
        document.getElementById('result').innerHTML = "Papel X Pedra = Vitória"
    }
    else if(machine == 2){
        document.getElementById('result').innerHTML = "Papel X Papel = Empate"
    }
    else{
        document.getElementById('result').innerHTML = "Papel X Tesoura = Derrota"
    }
}

let tesoura = function(){
    let machine = Math.round(Math.random() * (3 - 1) + 1)
    if(machine == 1){
        document.getElementById('result').innerHTML = "Tesoura X Pedra = Derrota"
    }
    else if(machine == 2){
        document.getElementById('result').innerHTML = "Tesoura X Papel = Vitória"
    }
    else{
        document.getElementById('result').innerHTML = "Tesoura X Tesoura = Empate"
    }
}